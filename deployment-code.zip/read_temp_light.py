# This script prints temperature readings from a DS18B20 temp sensor

# Parameters:
# sample_times = number of samples desired
# freq = interval in seconds between samples


def print_temp_light(sample_times = 10, freq = 5):

    # -------------------------------------------------------------------------------
    # Import libraries
    # -------------------------------------------------------------------------------
    from machine import Pin, I2C
    from onewire import OneWire
    from ds18x20 import DS18X20
    from time import sleep_ms
    from ustruct import unpack
    import tsl2591
    import urtc

    # -------------------------------------------------------------------------------
    # Set up GPIO pins for the DS18B20
    # -------------------------------------------------------------------------------

    p12 = Pin(12, Pin.OUT)  # Pin 12 is power supplied to the DS18B20, V+
    p12.value(1)            # set Pin 12 to 3V

    p14 = Pin(14, Pin.OUT)  # Pin 14 is GND for the DS18B20
    p14.value(0)            # Set Pin 14 to 0V

    ow = OneWire(Pin(13))   # Pin 13 is the data pin for the DS18B20
    ds = DS18X20(ow)        # Initialize a ds18b20 object

    # -------------------------------------------------------------------------------
    # Set up I2C devices
    # -------------------------------------------------------------------------------
    i2c = I2C(scl = Pin(5), sda = Pin(4)) # assign i2c pins

    # set up the clock
    p15 = Pin(15, Pin.OUT)  # Pin 15 is power supplied to the clock
    p15.value(1)            # set Pin 15 to 3V to turn on clock

    rtc = urtc.DS3231(i2c)

    # set up light sensors
    light = tsl2591.Tsl2591(i2c)

    # -------------------------------------------------------------------------------
    # Progression for obtaining temperature readings from the sensor
    # -------------------------------------------------------------------------------

    # set up Pin 0 so that the red LED blinks every time a sample is taken
    p0=Pin(0,Pin.OUT)        # Initiaze pin 0
    p0.value(1)              # Turn the LED off for now

    # create the loop that takes a sample based on how many samples you want
    for i in range(sample_times):

        p0.value(0)     # turn on red LED

        # print light reading
        t = rtc.datetime()
        timeStamp = str(str(t.year) + "-" + str(t.month) + "-" + str(t.day) + " " + \
                    str(t.hour) + ":" + str(t.minute) + ":" + str(t.second))

        # print light reading
        full, ir = light.get_full_luminosity()
        print(timeStamp, light.calculate_lux(full, ir))

        # print temp readings from all connected sensors
        roms = ds.scan()        # Find all the temp sensors that are attached
        ds.convert_temp()       # Obtain temp readings from each of those sensors
        sleep_ms(750)           # Sleep for 750 ms, to give the sensors enough time to report their temperature readings

        for rom in roms:        # Loop through all temp sensors attached (again, for our purposes we only have one)
            print(timeStamp, ds.read_temp(rom)) # print the temperature
            sleep_ms(500)      # Sleep for 0.5 sec

        print("\n")         # Print a line of space between temp readings so it is easier to read
        p0.value(1)         # Turn the LED off so we know the sensor is done reading

        sleep_ms(freq*1000)      # Wait before repeating the loop and taking another reading
