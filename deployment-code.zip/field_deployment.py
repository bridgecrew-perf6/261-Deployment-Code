#----------------------------------------------------------------------------
# OCN n61 basic temperature sensor
#
# Sensor field deployment code
# - Samples and save temperatures data with a time stamp
# - Saves a .csv data file
# 
#----------------------------------------------------------------------------



"""
How to use this code:

To sample continuously with sleep cycle connect Pin 16 to RST
To test code but not enter sleep cycle, connect Pin 16 to Pin 2 (GND)

This code establishes the function sample_temp() which takes three arguments:
- sleep_flag          
- sample_interval_sec 
- depth               

"sleep_flag" sets whether your sensor sleeps: 1 --> sleep; 0 --> no sleep (ex:sleep_flag = 0)
"sample_interval_sec" sets the number of seconds between desired temp readings (ex: sample_interval_sec=5*60)
"depth" lets you set the depth at which your sensor is located (ex: depth = 1.0)

default parameters are sleep_flag=0,sample_interval_sec=30,depth=1.0


#----------------------------------------------------------
Example usage (see below for additional parameter options):

>>>from field_deployment import sample_temp
>>>sample_temp(sleep_flag=1)

These parameters should be set/modified in main.py to trigger automatic sampling upon wakeup

Use Pin 16 to control sleep mode:
    When Pin 16 is connected to RST, Pin 16 is pulled high. This condition must be met for the sensor to sleep
    If Pin 16 is disconnected from RST and connected to GND, the sensor does not go to sleep.
"""


def sample_temp(sleep_flag=0,sample_interval_sec=30):
    from time import sleep_ms
    from machine import Pin, unique_id, I2C, RTC, DEEPSLEEP, deepsleep
    import urtc
    import tsl2591
    from gc import collect
    collect()

    # Use Pin 16 to prevent sleep: When connected to RST, as it must be to wake
    # from sleep, Pin 16 is pulled high. Check to see if Pin 16 is pulled low.
    # If it is disconnected from RST and connected to GND, prevent sleep.
    p16=Pin(16, mode=Pin.IN)
    if p16.value()==0:
        sleep_flag=0


    # Initialize onboard RTC
    rtc = RTC()

    # Keep checking if p16 is connected to GND
    if p16.value()==0:
        sleep_flag=0

    # LED on to show temps are being sampled
    p0=Pin(0,Pin.IN)    # Pin 0 is connected to an LED; initialize this to flash ever time temps
                        # are being obtained from the sensor

    # Set pin 2 to GND
    #p2 = Pin(2, Pin.OUT)    # Assign Pin 2 is GND for the RTC
    #p2.value(0)
    
    # -------------------------------------------------------------------------------
    # Set up the DS3231 external RTC
    # -------------------------------------------------------------------------------

    p15 = Pin(15, Pin.OUT)  # Assign Pin 15 to power the DS3231 RTC
    p15.value(1)            # Set Pin 15 high

    i2c = I2C(scl = Pin(5), sda = Pin(4))   # Initalize the I2C pins
    rtc3231 = urtc.DS3231(i2c)              # Assign the DS3231


    # -------------------------------------------------------------------------------
    # Set up the DS18B20 temperature sensor
    # -------------------------------------------------------------------------------
    from onewire import OneWire
    from ds18x20 import DS18X20
    collect()
    
    p12 = Pin(12, Pin.OUT)  # Assign Pin 12 to power the DS18B20
    p12.value(1)            # Set Pin 12 to high

    p14 = Pin(14, Pin.OUT)  # Assign Pin 14 to GND for the DS18B20
    p14.value(0)            # Set Pin 14 to 0V

    ow = OneWire(Pin(13))   # Assign Pin 13 as the data pin for the DS18B20
    ds = DS18X20(ow)        # Initialize a DS18B20 object

    # This is the progression for obtaining temperature readings from the sensors                       
    roms = ds.scan()  # Find all the DS18B20 sensors that are attached (we only have 1)
    ds.convert_temp() # Obtain temp readings from each of those sensors
    sleep_ms(750)     # Sleep for 750 ms, to give the sensors enough time to report their temperature readings

    # Keep checking if Pin 16 is connected to GND or not
    if p16.value()==0:
        sleep_flag=0
    

    # -------------------------------------------------------------------------------
    # Create the sleep cycle, set the interupt to wake up at the next sampling period
    # -------------------------------------------------------------------------------   
    rtc.irq(trigger=rtc.ALARM0, wake=DEEPSLEEP)
    rtc.alarm(rtc.ALARM0, 1000*sample_interval_sec) 
    sleep_ms(1000)      # sleep for 1 s

    # Keep checking if Pin 16 is connected to GND or not
    if p16.value()==0:
        sleep_flag=0


                    
    #-------------------------------
    # Sample and save data
    #-------------------------------

    # Sample temperature 
    roms = ds.scan()    
    ds.convert_temp()    
    sleep_ms(1000)      

    temp_big_string = ""
    for rom in roms:
        t_external = rtc3231.datetime()  # Obtain current time

        # create a time stamp for the collected data
        timeStamp = str(str(t_external.year) + "-" + str(t_external.month) + "-" + str(t_external.day) + "-" + \
                    str(t_external.hour) + "-" + str(t_external.minute) + "-" + str(t_external.second))

        # print time, depth and temperature
        print(timeStamp, ',',  ds.read_temp(rom))

        temp_big_string += str(timeStamp) + ',' + str(ds.read_temp(rom)) + ','

        sleep_ms(1000)      # Sleep for 1 sec


    t = rtc3231.datetime()
    ts = str(str(t.year) + "-" + str(t.month) + "-" + str(t.day) + "-" + \
         str(t.hour) + "-" + str(t.minute) + "-" + str(t.second))

    light_sensor = tsl2591.Tsl2591(i2c)
    full, ir = light_sensor.get_full_luminosity()
    lux_reading = light_sensor.calculate_lux(full, ir)

    freq = sample_interval_sec/60
    # save a new row of data to the data file
    datafile=open("temp_data_" + str(freq) + "min_interval.csv",'a')
    datafile.write(temp_big_string + ts + "," + str(lux_reading) + "\n")
    datafile.close()

    print("\n")

    #----------------------------------
    # Close connections/hardware gracefully, and prepare to sleep... 


    p12.value(0)

    sleep_ms(2000)

    if p16.value()==0:
        sleep_flag=0

    p0.value(1)         # Turn the LED off, by setting the pin high, so we know it is done taking a reading    

    sleep_ms(5000)

    # If in sleep mode and Pin 16 is connected to RST, go into deepsleep until the next sampling time.
    # If in sleep_flag=0 or Pin 16 is connected to GND, stop and wait for user to do something...
    print('p16.value=',p16.value())
    print('sleep_flag=',sleep_flag)
    
    if sleep_flag==1 and p16.value()==1:
        print('sleeping in 0.5 seconds...')
        sleep_ms(500)
        deepsleep()

